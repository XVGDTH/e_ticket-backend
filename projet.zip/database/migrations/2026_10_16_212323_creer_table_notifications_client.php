<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('notifications_client', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('type', 30); // achat, rappel, annulation, remboursement
            $table->string('titre');
            $table->text('corps');
            $table->foreignId('billet_id')->nullable()->constrained()->nullOnDelete();
            $table->string('billet_reference')->nullable();
            $table->timestamp('lu_a')->nullable();
            $table->timestamps();
            $table->softDeletes(); // supprimée par le voyageur : conservée en base
            $table->index(['user_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
        Schema::dropIfExists('notifications_client');
    }
};
