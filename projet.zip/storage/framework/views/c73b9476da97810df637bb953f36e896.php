<?php
    $utilisateur = auth()->user();
    $profil = $utilisateur?->profilStaff() ?? [];
    $compagnie = $utilisateur?->compagnieActuelle();
    $logo = $compagnie?->logo_affichable;
    // L'agent voit sa gare ; l'admin rattaché à une ville voit sa ville.
    $lieu = $profil['gare'] ?? $profil['ville'] ?? null;
?>

<div style="display:flex; align-items:center; gap:.6rem;">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($logo): ?>
        <img src="<?php echo e($logo); ?>" alt="<?php echo e($compagnie->nom); ?>" style="height:2.5rem; width:auto; max-width:5rem; object-fit:contain;">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div style="display:flex; flex-direction:column; line-height:1.15;">
        <span style="font-weight:700;"><?php echo e($compagnie?->nom ?? 'E-Ticket Admin'); ?></span>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lieu): ?>
            <span style="font-size:.75rem; opacity:.7;"><?php echo e($lieu); ?></span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div><?php /**PATH C:\Users\USER\Desktop\e_ticket-backend\resources\views/filament/marque.blade.php ENDPATH**/ ?>